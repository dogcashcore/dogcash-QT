Gitian building
================

This file was moved to [the DogCash Core documentation repository](https://github.com/dogcash-core/docs/blob/master/gitian-building.md) at [https://github.com/dogcash-core/docs](https://github.com/dogcash-core/docs).
