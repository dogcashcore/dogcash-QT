// Copyright (c) 2009-2016 The Bitcoin Core developers
// Copyright (c) 2017 The DogCash Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef PRODUCTIONCHAIN_RPCREGISTER_H
#define PRODUCTIONCHAIN_RPCREGISTER_H

/** These are in one header file to avoid creating tons of single-function
 * headers for everything under src/rpc/ */
class CRPCTable;

/** Register block chain RPC commands */
void RegisterBlockchainRDCHommands(CRPCTable &tableRPC);
/** Register P2P networking RPC commands */
void RegisterNetRDCHommands(CRPCTable &tableRPC);
/** Register miscellaneous RPC commands */
void RegisterMiscRDCHommands(CRPCTable &tableRPC);
/** Register mining RPC commands */
void RegisterMiningRDCHommands(CRPCTable &tableRPC);
/** Register raw transaction RPC commands */
void RegisterRawTransactionRDCHommands(CRPCTable &tableRPC);

static inline void RegisterAllCoreRDCHommands(CRPCTable &t)
{
    RegisterBlockchainRDCHommands(t);
    RegisterNetRDCHommands(t);
    RegisterMiscRDCHommands(t);
    RegisterMiningRDCHommands(t);
    RegisterRawTransactionRDCHommands(t);
}

#endif
