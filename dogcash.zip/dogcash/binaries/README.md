Releases have been moved to:

https://github.com/DogCashProject/DogCash/releases/latest
