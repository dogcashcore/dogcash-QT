Building DogCash
================

See doc/build-*.md for instructions on building the various
elements of the DogCash Core reference implementation of DogCash.
